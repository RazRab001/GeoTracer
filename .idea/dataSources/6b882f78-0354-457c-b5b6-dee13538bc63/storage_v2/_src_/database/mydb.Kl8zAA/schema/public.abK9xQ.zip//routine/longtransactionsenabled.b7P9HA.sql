create function longtransactionsenabled() returns boolean
    language plpgsql
as
$$
DECLARE
	rec RECORD;
BEGIN
	FOR rec IN SELECT oid FROM pg_class WHERE relname = 'authorized_tables'
	LOOP
		return 't';
	END LOOP;
	return 'f';
END;
$$;

alter function longtransactionsenabled() owner to "user";

